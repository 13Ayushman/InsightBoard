// === background.js ===

// Replace with your actual Make webhook URL from your Make scenario:
const WEBHOOK_URL = "https://hook.eu2.make.com/irb9tjq2bcjf5wuli5qk3r0im4atsgwi";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "saveToInsightBoard",
    title: "Save to InsightBoard",
    contexts: ["page"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "saveToInsightBoard" && tab) {
    const payload = {
      title: tab.title || "",
      url: tab.url || "",
      source: "Comet"
    };

    try {
      await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      console.log("✅ Sent to InsightBoard:", payload);
      alert("Page saved to InsightBoard!");
    } catch (e) {
      console.error("❌ Webhook error:", e);
      alert("Error sending to InsightBoard. Check console.");
    }
  }
});
